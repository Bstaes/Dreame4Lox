#!/bin/bash
# Dreame4Lox — Post-Install Script

echo "=== Dreame4Lox v0.3.0 post-install ==="

# ── Python dependencies ───────────────────────────────────────────────────────
echo "Installing Python dependencies..."
pip3 install requests paho-mqtt --break-system-packages --quiet 2>&1 \
    && echo "  OK: requests + paho-mqtt" \
    || pip3 install requests paho-mqtt --user --quiet 2>&1

# ── File permissions ──────────────────────────────────────────────────────────
chmod +x "$LBPBINDIR/dreame_bridge.py"
chmod +x "$LBPBINDIR/dreame_discover.py"
chmod +x "$LBPBINDIR/dreame_cloud.py"
chmod +x "$LBPBINDIR/dreame4lox_daemon.sh"

# ── Directories & default config ──────────────────────────────────────────────
# The daemon script creates dirs and default config on first run.
# Call it here so everything is ready before the UI opens.
bash "$LBPBINDIR/dreame4lox_daemon.sh" status > /dev/null 2>&1 || true

# ── Verify Python library ─────────────────────────────────────────────────────
echo "Verifying Python library..."
python3 -W ignore -c "
import sys
sys.path.insert(0, '$LBPBINDIR')
from dreame_cloud import DreameHomeCloud
c = DreameHomeCloud('test','test','eu')
print('  dreame_cloud.py OK — endpoint:', c._base_url())
" 2>&1

echo ""
echo "Install complete. Open the plugin UI to configure your Dreame Home account."
exit 0
