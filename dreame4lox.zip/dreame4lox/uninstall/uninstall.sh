#!/bin/bash
# Dreame4Lox - Uninstall Script
echo "Dreame4Lox uninstalled. Python packages (miio, paho-mqtt) were NOT removed as they may be used by other plugins."
exit 0
