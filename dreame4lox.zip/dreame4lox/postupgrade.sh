#!/bin/bash
# Dreame4Lox — Post-Upgrade Script
echo "Dreame4Lox post-upgrade..."
pip3 install requests paho-mqtt --break-system-packages --quiet 2>&1 || true
chmod +x "$LBPBINDIR/dreame_bridge.py"
chmod +x "$LBPBINDIR/dreame_discover.py"
chmod +x "$LBPBINDIR/dreame_cloud.py"
chmod +x "$LBPBINDIR/dreame4lox_daemon.sh"
# Restart daemon if running so it picks up new code
if pgrep -f "dreame_bridge.py" > /dev/null 2>&1; then
    echo "Restarting daemon..."
    bash "$LBPBINDIR/dreame4lox_daemon.sh" restart
fi
echo "Upgrade complete."
exit 0
