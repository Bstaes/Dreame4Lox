<?php
/**
 * Dreame4Lox — Web UI
 * LoxBerry plugin to connect Dreame Home robots to Loxone.
 * Works directly with Dreame Home cloud (no Mi Home / Home Assistant needed).
 */

require_once "loxberry_web.php";
require_once "loxberry_system.php";

$template_title = "Dreame4Lox";
$cfgfile  = $lbpconfigdir . "/dreame4lox.json";
$logfile  = $lbplogdir    . "/dreame4lox_daemon.log";
$daemon   = $lbpbindir    . "/dreame4lox_daemon.sh";
$discover = $lbpbindir    . "/dreame_discover.py";

function loadCfg($p) {
    if (!file_exists($p)) return defaultCfg();
    $c = json_decode(file_get_contents($p), true);
    return $c ?: defaultCfg();
}
function defaultCfg() {
    return ["dreame_username"=>"","dreame_password"=>"","dreame_country"=>"eu",
            "robots"=>[],"mqtt"=>["enabled"=>true,"broker"=>"localhost","port"=>1883,
            "user"=>"","password"=>"","base_topic"=>"dreame4lox"],
            "loxone"=>["miniserver_ip"=>"","udp_port"=>7777],
            "http_port"=>7778,"poll_interval"=>30];
}

if (isset($_GET["action"])) {
    header("Content-Type: application/json");
    $cfg = loadCfg($cfgfile);

    if ($_GET["action"] === "get_config") { echo json_encode($cfg); exit; }

    if ($_GET["action"] === "save") {
        $d = json_decode(file_get_contents("php://input"), true);
        if ($d) { file_put_contents($cfgfile, json_encode($d, JSON_PRETTY_PRINT)); echo json_encode(["ok"=>true]); }
        else     { echo json_encode(["ok"=>false,"error"=>"Invalid JSON"]); }
        exit;
    }

    if ($_GET["action"] === "daemon_status") {
        $s = trim(shell_exec("bash $daemon status 2>&1"));
        echo json_encode(["status"=>$s]); exit;
    }
    if ($_GET["action"] === "daemon_start") {
        $out = shell_exec("bash $daemon start 2>&1");
        sleep(2);
        $status = trim(shell_exec("bash $daemon status 2>&1"));
        echo json_encode(["status"=>$status, "output"=>$out]); exit;
    }
    if ($_GET["action"] === "daemon_stop") {
        $out = shell_exec("bash $daemon stop 2>&1");
        sleep(1);
        echo json_encode(["status"=>"stopped","output"=>$out]); exit;
    }
    if ($_GET["action"] === "daemon_test") {
        // Run bridge script directly for 3 seconds to catch startup errors
        $bin     = $lbpbindir    . "/dreame_bridge.py";
        $cfgf    = $lbpconfigdir . "/dreame4lox.json";
        $logf    = $lbplogdir    . "/dreame4lox_daemon.log";
        $cmd     = "timeout 4 python3 -W ignore $bin --config $cfgf --loglevel DEBUG 2>&1";
        $out     = shell_exec($cmd);
        // Also grab last 20 lines of log
        $log = "";
        if (file_exists($logf)) {
            $log = implode("", array_slice(file($logf), -20));
        }
        echo json_encode(["output"=>$out, "log"=>$log]); exit;
    }

    if ($_GET["action"] === "discover") {
        $user = escapeshellarg($_GET["username"] ?? $cfg["dreame_username"] ?? "");
        $pass = escapeshellarg($_GET["password"] ?? $cfg["dreame_password"] ?? "");
        $ctry = escapeshellarg($_GET["country"]  ?? $cfg["dreame_country"]  ?? "eu");
        $out  = shell_exec("python3 -W ignore $discover --username $user --password $pass --country $ctry 2>/dev/null");
        $res  = json_decode($out, true);
        echo json_encode($res ?: ["devices"=>[],"warnings"=>[["type"=>"parse_error","message"=>substr($out,0,200)]]]);
        exit;
    }

    if ($_GET["action"] === "send_command") {
        $robot = urlencode($_GET["robot"] ?? "");
        $cmd   = urlencode($_GET["cmd"]   ?? "");
        $port  = intval($cfg["http_port"] ?? 7778);
        $resp  = @file_get_contents("http://localhost:$port/command?robot=$robot&cmd=$cmd");
        echo json_encode(["ok"=>$resp!==false,"response"=>$resp]); exit;
    }

    if ($_GET["action"] === "get_status") {
        $port = intval($cfg["http_port"] ?? 7778);
        $resp = @file_get_contents("http://localhost:$port/status");
        $data = $resp ? json_decode($resp, true) : [];
        echo json_encode($data ?: []); exit;
    }

    if ($_GET["action"] === "get_log") {
        if (file_exists($logfile)) {
            $lines = array_slice(file($logfile), -100);
            echo json_encode(["log"=>implode("",$lines)]);
        } else { echo json_encode(["log"=>"(no log yet)"]); }
        exit;
    }

    if ($_GET["action"] === "install_deps") {
        $out = shell_exec("pip3 install requests paho-mqtt --break-system-packages 2>&1");
        $ok  = strpos($out,"Successfully installed")!==false || strpos($out,"already satisfied")!==false;
        echo json_encode(["ok"=>$ok,"output"=>$out]); exit;
    }

    echo json_encode(["error"=>"Unknown action"]); exit;
}

LBWeb::lbheader($template_title, "", "");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dreame4Lox</title>
<style>
body{font-family:sans-serif;background:#1a1a2e;color:#e0e0e0;margin:0;padding:0}
.container{max-width:960px;margin:0 auto;padding:20px}
h1{color:#00d4ff;font-size:1.6em;margin-bottom:4px}
h2{color:#00aacc;font-size:1.1em;border-bottom:1px solid #333;padding-bottom:6px;margin-top:28px}
.subtitle{color:#888;font-size:.85em;margin-bottom:20px}
.card{background:#16213e;border-radius:10px;padding:20px;margin-bottom:20px;border:1px solid #0f3460}
.robot-card{background:#0d1b2a;border-radius:8px;padding:14px;margin-bottom:12px;border:1px solid #1a4a6e}
.badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:.75em;font-weight:bold}
.badge-cleaning{background:#00aa44;color:#fff}.badge-charging{background:#ffaa00;color:#000}
.badge-idle,.badge-sleeping{background:#555;color:#fff}.badge-error,.badge-auth_error,.badge-unreachable{background:#cc0000;color:#fff}
.badge-unknown,.badge-paused,.badge-returning{background:#335;color:#aaf}
.daemon-running{color:#00ff88}.daemon-stopped{color:#ff5555}
input[type=text],input[type=number],input[type=password],select{background:#0d1b2a;color:#e0e0e0;border:1px solid #1a4a6e;border-radius:4px;padding:6px 10px;width:100%;box-sizing:border-box;margin-bottom:8px}
.btn{display:inline-block;padding:8px 16px;border-radius:5px;border:none;cursor:pointer;font-size:.9em;margin:4px 2px}
.btn-primary{background:#0f3460;color:#00d4ff}.btn-success{background:#005522;color:#00ff88}
.btn-danger{background:#440000;color:#ff6666}.btn-warning{background:#4a3000;color:#ffcc00}
.btn-info{background:#003344;color:#44ddff}.btn:hover{opacity:.85}
.row{display:flex;gap:12px;flex-wrap:wrap}.col{flex:1;min-width:200px}
label{font-size:.82em;color:#aaa;display:block;margin-bottom:2px}
.progress-bar{background:#0d1b2a;border-radius:4px;height:10px;overflow:hidden;margin:4px 0}
.progress-fill{height:100%;border-radius:4px;transition:width .5s}
.pf-green{background:#00aa44}.pf-yellow{background:#ffaa00}.pf-red{background:#cc0000}
#logBox{background:#0a0f1a;border:1px solid #1a4a6e;border-radius:6px;padding:12px;font-family:monospace;font-size:.78em;height:220px;overflow-y:auto;white-space:pre-wrap;color:#aaffaa}
.tabs{display:flex;gap:4px;margin-bottom:20px;flex-wrap:wrap}
.tab{padding:8px 16px;border-radius:6px 6px 0 0;cursor:pointer;background:#0d1b2a;color:#888;border:1px solid #1a4a6e;border-bottom:none}
.tab.active{background:#16213e;color:#00d4ff}
.tab-content{display:none}.tab-content.active{display:block}
.toggle-row{display:flex;align-items:center;gap:10px;margin-bottom:8px}
input[type=checkbox]{width:auto}
code{background:#0a0f1a;padding:2px 6px;border-radius:3px;font-size:.85em}
.info-box{background:#0a1a2a;border:1px solid #0088cc;border-radius:6px;padding:10px 14px;margin-bottom:10px;color:#88ccff;font-size:.85em;line-height:1.6}
.warn-box{background:#2a1a00;border:1px solid #f80;border-radius:6px;padding:10px 14px;margin-bottom:10px;color:#fc0;font-size:.85em;line-height:1.6}
.err-box{background:#2a0000;border:1px solid #f55;border-radius:6px;padding:10px 14px;margin-bottom:10px;color:#f99;font-size:.85em;line-height:1.6}
</style>
</head><body>
<div class="container">
<h1>🤖 Dreame4Lox</h1>
<p class="subtitle">Direct Dreame Home cloud integration for Loxone — no Home Assistant needed</p>

<div class="card" style="padding:12px 20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap">
  <div>Daemon: <span id="daemonStatus" class="daemon-stopped">checking…</span></div>
  <button class="btn btn-success" onclick="daemonStart()">▶ Start</button>
  <button class="btn btn-danger"  onclick="daemonStop()">■ Stop</button>
  <button class="btn btn-info"    onclick="loadStatus()">↻ Refresh</button>
  <button class="btn btn-warning" onclick="daemonTest()" title="Run bridge for 4s and show any errors">🔧 Test</button>
  <span style="margin-left:auto;color:#555;font-size:.8em">Dreame4Lox v0.2.0</span>
</div>

<pre id="daemonTestOut" style="display:none;background:#0a0f1a;border:1px solid #f80;border-radius:6px;padding:12px;color:#fc0;font-size:.75em;max-height:300px;overflow-y:auto;white-space:pre-wrap;margin-bottom:16px"></pre>

<div class="tabs">
  <div class="tab active" onclick="showTab('tab-robots',this)">Robots</div>
  <div class="tab"        onclick="showTab('tab-account',this)">Account</div>
  <div class="tab"        onclick="showTab('tab-mqtt',this)">MQTT</div>
  <div class="tab"        onclick="showTab('tab-loxone',this)">Loxone Setup</div>
  <div class="tab"        onclick="showTab('tab-log',this)">Log</div>
</div>

<!-- ═══ ROBOTS ═══ -->
<div id="tab-robots" class="tab-content active">
  <h2>Live Status</h2>
  <div id="liveArea"><em style="color:#555">Loading…</em></div>

  <h2>Configured Robots</h2>
  <div class="info-box">
    Each robot needs its <b>Device ID (did)</b>. Use the <b>Account</b> tab to discover
    your robots and auto-fill them, or find the DID in the Dreame Home app under
    Device Info → Device ID.
  </div>
  <div id="robotList"></div>
  <button class="btn btn-primary" onclick="addRobot()">+ Add Robot</button>
  <br><br>
  <button class="btn btn-success" onclick="saveAll()">💾 Save</button>
</div>

<!-- ═══ ACCOUNT ═══ -->
<div id="tab-account" class="tab-content">
  <h2>Dreame Home Cloud Account</h2>
  <div class="card">
    <div class="info-box">
      Enter your <b>Dreame Home app</b> credentials (the app with the robot icon,
      not Mi Home). These are used both for discovering robots and for ongoing control.
      Credentials are stored locally on your LoxBerry — they are never sent anywhere
      except to Dreame's own cloud servers.
    </div>
    <div class="row">
      <div class="col">
        <label>Email address</label>
        <input type="text" id="dreameUser" placeholder="you@email.com">
      </div>
      <div class="col">
        <label>Password</label>
        <input type="password" id="dreamePass" placeholder="">
      </div>
      <div class="col" style="max-width:160px">
        <label>Server region</label>
        <select id="dreameCountry">
          <option value="eu" selected>Europe (eu)</option>
          <option value="us">USA (us)</option>
          <option value="cn">China (cn)</option>
          <option value="sg">Singapore (sg)</option>
          <option value="kr">Korea (kr)</option>
          <option value="in">India (in)</option>
          <option value="ru">Russia (ru)</option>
        </select>
      </div>
    </div>
    <button class="btn btn-success" onclick="saveAll()">💾 Save credentials</button>
    <button class="btn btn-info"    onclick="discoverRobots()" style="margin-left:8px">🔍 Discover my robots</button>
    <div id="discoverResult" style="margin-top:14px"></div>
  </div>
</div>

<!-- ═══ MQTT ═══ -->
<div id="tab-mqtt" class="tab-content">
  <h2>MQTT Settings</h2>
  <div class="card">
    <div class="toggle-row">
      <input type="checkbox" id="mqttEnabled">
      <label for="mqttEnabled" style="display:inline;color:#ccc">Enable MQTT publishing</label>
    </div>
    <div class="row">
      <div class="col"><label>Broker host</label><input type="text" id="mqttBroker" placeholder="localhost"></div>
      <div class="col" style="max-width:100px"><label>Port</label><input type="number" id="mqttPort" value="1883"></div>
    </div>
    <div class="row">
      <div class="col"><label>Username (optional)</label><input type="text" id="mqttUser"></div>
      <div class="col"><label>Password (optional)</label><input type="password" id="mqttPass"></div>
    </div>
    <div class="row">
      <div class="col"><label>Base topic</label><input type="text" id="mqttTopic" value="dreame4lox"></div>
      <div class="col" style="max-width:120px"><label>Poll interval (s)</label><input type="number" id="pollInterval" value="30" min="10"></div>
    </div>
    <button class="btn btn-success" onclick="saveAll()">💾 Save</button>
  </div>
</div>

<!-- ═══ LOXONE SETUP ═══ -->
<div id="tab-loxone" class="tab-content">
  <h2>Miniserver Connection</h2>
  <div class="card">
    <div class="row">
      <div class="col"><label>Miniserver IP</label><input type="text" id="loxoneIp" placeholder="192.168.1.100"></div>
      <div class="col" style="max-width:120px"><label>UDP port</label><input type="number" id="loxonePort" value="7777"></div>
      <div class="col" style="max-width:120px"><label>HTTP cmd port</label><input type="number" id="httpPort" value="7778"></div>
    </div>
    <button class="btn btn-success" onclick="saveAll()">💾 Save</button>
  </div>

  <h2>Virtual UDP Input (receiving status)</h2>
  <div class="card">
    <p style="color:#aaa;font-size:.9em;line-height:1.7em">
      Create a <b>Virtual UDP Input</b> on port <b>7777</b>.<br>
      Add <b>Virtual UDP Input Commands</b>:
    </p>
    <table style="font-size:.82em;color:#aaa;border-collapse:collapse;width:100%">
      <tr style="color:#00d4ff"><th align="left" style="padding:4px 8px">Command Recognition</th><th align="left" style="padding:4px 8px">Value</th></tr>
      <?php foreach([
        ["DREAME\\i/STATE=\\v",    "0=idle 1=cleaning 2=returning 3=charging 4=paused 5=error"],
        ["DREAME\\i/BATTERY=\\v",  "Battery %"],
        ["DREAME\\i/CLEANING=\\v", "1=cleaning 0=not"],
        ["DREAME\\i/CHARGING=\\v", "1=charging 0=not"],
        ["DREAME\\i/ERROR=\\v",    "1=error 0=ok"],
        ["DREAME\\i/AREA=\\v",     "Cleaned area m²"],
        ["DREAME\\i/TIME=\\v",     "Cleaning time (min)"],
        ["DREAME\\i/MAINBRUSH=\\v","Main brush life %"],
        ["DREAME\\i/SIDEBRUSH=\\v","Side brush life %"],
        ["DREAME\\i/FILTER=\\v",   "Filter life %"],
      ] as [$cmd,$desc]): ?>
      <tr style="border-top:1px solid #1a4a6e">
        <td style="padding:4px 8px"><code><?= $cmd ?></code></td>
        <td style="padding:4px 8px"><?= $desc ?></td>
      </tr>
      <?php endforeach ?>
    </table>
    <p style="color:#888;font-size:.82em;margin-top:8px">Replace <code>\i</code> with your robot name e.g. <code>X50_Ultra</code></p>
  </div>

  <h2>Virtual HTTP Output (sending commands)</h2>
  <div class="card">
    <p style="color:#aaa;font-size:.9em;line-height:1.7em">
      Create a <b>Virtual HTTP Output</b> with address: <code>http://&lt;loxberry-ip&gt;:7778</code><br>
      Add <b>Virtual HTTP Output Commands</b>:
    </p>
    <table style="font-size:.82em;color:#aaa;border-collapse:collapse;width:100%">
      <tr style="color:#00d4ff"><th align="left" style="padding:4px 8px">URL (ON command)</th><th align="left" style="padding:4px 8px">Action</th></tr>
      <?php foreach([
        ["/command?robot=X50_Ultra&cmd=start",   "Start full clean"],
        ["/command?robot=X50_Ultra&cmd=dock",    "Return to dock"],
        ["/command?robot=X50_Ultra&cmd=pause",   "Pause"],
        ["/command?robot=X50_Ultra&cmd=stop",    "Stop"],
        ["/command?robot=X50_Ultra&cmd=locate",  "Locate (beep)"],
        ["/command?robot=X50_Ultra&cmd=start_room&segments=[3,5]","Clean rooms 3 and 5"],
      ] as [$url,$desc]): ?>
      <tr style="border-top:1px solid #1a4a6e">
        <td style="padding:4px 8px"><code><?= $url ?></code></td>
        <td style="padding:4px 8px"><?= $desc ?></td>
      </tr>
      <?php endforeach ?>
    </table>
    <p style="color:#888;font-size:.82em;margin-top:8px">Set HTTP Method = GET, enable Digital Input.</p>
  </div>
</div>

<!-- ═══ LOG ═══ -->
<div id="tab-log" class="tab-content">
  <h2>Daemon Log</h2>
  <button class="btn btn-info" onclick="loadLog()" style="margin-bottom:10px">↻ Refresh</button>
  <div id="logBox">Loading…</div>
</div>

</div><!-- /container -->
<script>
let config = null;

function showTab(id, el) {
  document.querySelectorAll('.tab-content').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  if (el) el.classList.add('active');
  if (id==='tab-log') loadLog();
}

async function api(action, body=null) {
  const o = {method: body?'POST':'GET'};
  if (body) { o.headers={'Content-Type':'application/json'}; o.body=JSON.stringify(body); }
  return (await fetch('?action='+action, o)).json();
}

async function loadConfig() {
  config = await api('get_config');
  renderAccountForm();
  renderMqttForm();
  renderRobotList();
  checkDaemon();
  loadStatus();
}

function renderAccountForm() {
  if (!config) return;
  document.getElementById('dreameUser').value    = config.dreame_username || '';
  document.getElementById('dreamePass').value    = config.dreame_password || '';
  const sel = document.getElementById('dreameCountry');
  if (config.dreame_country) sel.value = config.dreame_country;
}

function renderMqttForm() {
  if (!config) return;
  const m = config.mqtt || {};
  document.getElementById('mqttEnabled').checked = m.enabled !== false;
  document.getElementById('mqttBroker').value    = m.broker || 'localhost';
  document.getElementById('mqttPort').value      = m.port   || 1883;
  document.getElementById('mqttUser').value      = m.user   || '';
  document.getElementById('mqttPass').value      = m.password || '';
  document.getElementById('mqttTopic').value     = m.base_topic || 'dreame4lox';
  document.getElementById('pollInterval').value  = config.poll_interval || 30;
  document.getElementById('loxoneIp').value      = (config.loxone||{}).miniserver_ip || '';
  document.getElementById('loxonePort').value    = (config.loxone||{}).udp_port || 7777;
  document.getElementById('httpPort').value      = config.http_port || 7778;
}

function renderRobotList() {
  const list = document.getElementById('robotList');
  if (!config || !config.robots || !config.robots.length) {
    list.innerHTML = '<p style="color:#555">No robots yet. Discover them in the Account tab, or add manually.</p>';
    return;
  }
  list.innerHTML = '';
  config.robots.forEach((r,i) => {
    const d = document.createElement('div');
    d.className = 'robot-card';
    d.innerHTML = `
      <div class="row" style="align-items:center">
        <div class="col">
          <label>Name (used in Loxone commands)</label>
          <input type="text" value="${esc(r.name||'')}" placeholder="e.g. X50_Ultra"
              oninput="config.robots[${i}].name=this.value">
        </div>
        <div class="col">
          <label>Device ID (did)</label>
          <input type="text" value="${esc(r.did||'')}" placeholder="12345678"
              oninput="config.robots[${i}].did=this.value" style="font-family:monospace">
        </div>
        <div class="col" style="max-width:80px">
          <label>Model</label>
          <input type="text" value="${esc(r.model||'')}" placeholder="auto"
              oninput="config.robots[${i}].model=this.value">
        </div>
      </div>
      <div class="row" style="margin-top:6px;align-items:center">
        <div style="flex:1">
          <div class="toggle-row" style="margin:0">
            <input type="checkbox" id="en${i}" ${r.enabled!==false?'checked':''} onchange="config.robots[${i}].enabled=this.checked">
            <label for="en${i}" style="display:inline;color:#aaa;font-size:.85em">Enabled</label>
          </div>
        </div>
        <div>
          <button class="btn btn-danger" style="padding:3px 10px;font-size:.8em" onclick="config.robots.splice(${i},1);renderRobotList()">✕ Remove</button>
        </div>
      </div>`;
    list.appendChild(d);
  });
}

function addRobot() {
  if (!config) return;
  config.robots.push({name:'New_Robot',did:'',model:'',enabled:true});
  renderRobotList();
}

// ── Live status ────────────────────────────────────────────────────────────────
async function loadStatus() {
  const area = document.getElementById('liveArea');
  area.innerHTML = '<em style="color:#555">Fetching…</em>';
  try {
    const statuses = await api('get_status');
    if (!statuses || !statuses.length) {
      area.innerHTML = '<p style="color:#555">No live data yet. Start the daemon and wait for the first poll cycle.</p>';
      return;
    }
    area.innerHTML = '';
    statuses.forEach(s => {
      const sc = ({cleaning:'badge-cleaning',charging:'badge-charging',idle:'badge-idle',
                   sleeping:'badge-sleeping',error:'badge-error',auth_error:'badge-error',
                   unreachable:'badge-error',returning:'badge-returning',paused:'badge-paused'})[s.state]||'badge-unknown';
      const bc = s.battery>50?'pf-green':s.battery>20?'pf-yellow':'pf-red';
      const card = document.createElement('div');
      card.className = 'robot-card';
      card.innerHTML = `
        <h3 style="margin:0 0 8px;color:#00d4ff">🤖 ${esc(s.name)} <span class="badge ${sc}">${esc(s.state)}</span></h3>
        <div class="row">
          <div class="col">
            <label>Battery</label>
            <div class="progress-bar"><div class="progress-fill ${bc}" style="width:${Math.max(0,s.battery||0)}%"></div></div>
            <span style="font-size:.8em">${s.battery}%</span>
          </div>
          <div class="col"><label>Area</label><div>${s.cleaned_area} m²</div></div>
          <div class="col"><label>Time</label><div>${s.cleaning_time} min</div></div>
        </div>
        <div class="row" style="margin-top:6px">
          <div class="col"><label>Main brush</label>${s.main_brush_left}%</div>
          <div class="col"><label>Side brush</label>${s.side_brush_left}%</div>
          <div class="col"><label>Filter</label>${s.filter_left}%</div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px">
          <button class="btn btn-success" onclick="sendCmd('${esc(s.name)}','start')">▶ Start</button>
          <button class="btn btn-warning" onclick="sendCmd('${esc(s.name)}','pause')">⏸ Pause</button>
          <button class="btn btn-info"    onclick="sendCmd('${esc(s.name)}','dock')">⏏ Dock</button>
          <button class="btn btn-danger"  onclick="sendCmd('${esc(s.name)}','stop')">■ Stop</button>
          <button class="btn btn-primary" onclick="sendCmd('${esc(s.name)}','locate')">📍 Locate</button>
        </div>
        <div style="font-size:.72em;color:#555;margin-top:6px">DID: ${esc(s.did)} | ${esc(s.last_updated||'')}</div>`;
      area.appendChild(card);
    });
  } catch(e) {
    area.innerHTML = '<p style="color:#f55">Error loading status — is the daemon running?</p>';
  }
}

async function sendCmd(robot, cmd) {
  const res = await fetch(`?action=send_command&robot=${encodeURIComponent(robot)}&cmd=${encodeURIComponent(cmd)}`);
  const d   = await res.json();
  alert(d.ok ? `✓ '${cmd}' sent to ${robot}` : `✗ Failed: ${d.response}`);
}

// ── Daemon ────────────────────────────────────────────────────────────────────
async function checkDaemon() {
  const el = document.getElementById('daemonStatus');
  const d  = await api('daemon_status');
  const ok = (d.status||'').trim().toLowerCase()==='running';
  el.textContent = ok ? '● Running' : '● Stopped';
  el.className   = ok ? 'daemon-running' : 'daemon-stopped';
}
async function daemonStart() {
  const d = await api('daemon_start');
  checkDaemon();
  if (d.output && d.output.trim()) {
    console.log('Daemon start output:', d.output);
  }
  if (d.status !== 'running' && d.output) {
    alert('Daemon did not start:\n\n' + d.output.trim().slice(0, 500));
  }
  setTimeout(loadStatus, 4000);
}
async function daemonStop() { await api('daemon_stop'); checkDaemon(); }
async function daemonTest() {
  const el = document.getElementById('daemonTestOut');
  el.style.display = 'block';
  el.textContent = 'Running 4-second test…';
  const d = await api('daemon_test');
  const out = (d.output || '(no output)').trim();
  const log = (d.log    || '(no log)').trim();
  el.textContent = '=== stdout/stderr ===\n' + out + '\n\n=== last log lines ===\n' + log;
}

// ── Discover ──────────────────────────────────────────────────────────────────
async function discoverRobots() {
  const el   = document.getElementById('discoverResult');
  const user = document.getElementById('dreameUser').value;
  const pass = document.getElementById('dreamePass').value;
  const ctry = document.getElementById('dreameCountry').value;
  el.innerHTML = '<em style="color:#888">Connecting to Dreame cloud…</em>';

  const p = new URLSearchParams({action:'discover',username:user,password:pass,country:ctry});
  let data;
  try {
    data = await (await fetch('?'+p)).json();
  } catch(e) {
    el.innerHTML = `<div class="err-box">Request failed: ${esc(String(e))}</div>`;
    return;
  }

  let html = '';

  (data.warnings||[]).forEach(w => {
    const t   = typeof w==='object' ? (w.type||'') : '';
    const msg = typeof w==='object' ? (w.message||JSON.stringify(w)) : String(w);
    html += `<div class="${t==='auth_failed'?'err-box':'warn-box'}">${esc(msg)}</div>`;
  });

  if (!data.devices || !data.devices.length) {
    if (!(data.warnings||[]).length)
      html += '<div class="warn-box">No robots found. Check email/password and region.</div>';
    el.innerHTML = html;
    return;
  }

  html += `<p style="color:#0f0;margin-bottom:8px">Found ${data.devices.length} robot(s):</p>`;
  el.innerHTML = html;

  data.devices.forEach(d => {
    const div = document.createElement('div');
    div.style.cssText = 'background:#0a0f1a;padding:10px 14px;border-radius:6px;margin-bottom:8px;border:1px solid #1a4a6e';
    div.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <b style="color:#00d4ff">${esc(d.name)}</b>
        <span style="color:#888;font-size:.8em">${esc(d.model)}</span>
        ${d.ip?`<span style="color:#555;font-size:.75em">IP: ${esc(d.ip)}</span>`:''}
      </div>
      <div style="font-size:.82em;color:#aaa;margin:3px 0">DID: <code>${esc(d.did)}</code></div>
      <button class="btn btn-primary" style="padding:3px 10px;font-size:.8em;margin-top:4px"
        onclick="addDiscovered('${esc(d.did)}','${esc(d.name)}','${esc(d.model)}')">+ Add to config</button>`;
    el.appendChild(div);
  });
}

function addDiscovered(did, name, model) {
  if (!config) return;
  const safeName = name.replace(/\s+/g,'_');
  config.robots.push({did, name:safeName, model, enabled:true});
  renderRobotList();
  showTab('tab-robots', document.querySelector('.tabs .tab'));
}

// ── Save ──────────────────────────────────────────────────────────────────────
async function saveAll() {
  if (!config) return;
  config.dreame_username = document.getElementById('dreameUser').value;
  config.dreame_password = document.getElementById('dreamePass').value;
  config.dreame_country  = document.getElementById('dreameCountry').value;
  config.mqtt = {
    enabled:    document.getElementById('mqttEnabled').checked,
    broker:     document.getElementById('mqttBroker').value,
    port:       parseInt(document.getElementById('mqttPort').value),
    user:       document.getElementById('mqttUser').value,
    password:   document.getElementById('mqttPass').value,
    base_topic: document.getElementById('mqttTopic').value,
  };
  config.poll_interval = parseInt(document.getElementById('pollInterval').value);
  config.http_port     = parseInt(document.getElementById('httpPort').value);
  config.loxone = {
    miniserver_ip: document.getElementById('loxoneIp').value,
    udp_port:      parseInt(document.getElementById('loxonePort').value),
  };
  const r = await api('save', config);
  alert(r.ok ? '✓ Saved! Restart the daemon for changes to take effect.' : '✗ Save failed.');
}

async function loadLog() {
  const box = document.getElementById('logBox');
  const d   = await api('get_log');
  box.textContent = d.log || '(empty)';
  box.scrollTop = box.scrollHeight;
}

function esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

loadConfig();
setInterval(checkDaemon, 15000);
</script>
<?php LBWeb::lbfooter(); ?>
</body></html>
